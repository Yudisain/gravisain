<?php
/**
 * Gravisain Child Theme Functions
 */

add_action( 'wp_enqueue_scripts', 'gravisain_child_enqueue_styles', 20 );

function gravisain_child_enqueue_styles() {
	// The parent theme's style.css is usually enqueued automatically by Gravisain's Assets class.
	// We just need to enqueue the child theme's style.css if you want to add custom CSS here.
	wp_enqueue_style(
		'gravisain-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[ 'gravisain-style' ],
		wp_get_theme()->get( 'Version' )
	);
}
